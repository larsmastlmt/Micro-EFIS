# MicroEFIS_Mavlink_T4
Micro EFIS emulator to RC airplane

This project is a Garmin FlightDeck Emulator to RC model.

It's project uses the libraries:
 - ILI9341_t3n - https://github.com/KurtE/ILI9341_t3n
 - Mavlink - https://github.com/mavlink
 - Thread - Juraj

Demonstration video: https://www.youtube.com/watch?v=rurBo2GL1DU

# Wiring Diagram
![alt text](https://github.com/paulopilot/MicroEFIS_Mavlink_T4/blob/main/images/Wiring%20Diagram.png?raw=true)
